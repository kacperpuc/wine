import React from 'react'
import ReactDOM from 'react-dom/client'
import KalkulatorLaffort from './KalkulatorLaffort'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <KalkulatorLaffort />
  </React.StrictMode>,
)
